criaCartao(
    'Programação',
    'O que é Python?',
    'O Python é uma linguagem de programação'
)

criaCartao(
    'Programação',
    'Por que aprender programar?',
    'Mercado de trabalho esta exigindo pessoas com habilidade em linguaguem de programação, é um diferencial'
)

criaCartao(
    'Programação',
    'O que é uma função?',
    'Uma função é um bloco de código que executa alguma tarefa'
)

criaCartao(
    'Nota Bimestre',
    'Quando finaliza nosso bimestre?',
    'As notas serão fechadas a partir de 27/11'
)